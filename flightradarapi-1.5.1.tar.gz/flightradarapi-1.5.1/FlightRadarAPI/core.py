# -*- coding: utf-8 -*-

from enum import Enum
from .zones import static_zones


class Core:

    # Base URLs.
    api_flightradar_base_url = "https://api.flightradar24.com/common/v1"
    cdn_flightradar_base_url = "https://cdn.flightradar24.com"
    flightradar_base_url = "https://www.flightradar24.com"
    data_live_base_url = "https://data-live.flightradar24.com"
    data_cloud_base_url = "https://data-cloud.flightradar24.com"

    # User login URL.
    user_login_url = flightradar_base_url + "/user/login"
    user_logout_url = flightradar_base_url + "/user/logout"

    # Search data URL
    search_data_url = flightradar_base_url + "/v1/search/web/find?query={}&limit={}"

    # Flights data URLs.
    real_time_flight_tracker_data_url = data_cloud_base_url + "/zones/fcgi/feed.js"
    flight_data_url = data_live_base_url + "/clickhandler/?flight={}"

    # Historical data URL.
    historical_data_url = flightradar_base_url + "/download/?flight={}&file={}&trailLimit=0&history={}"

    # Airports data URLs.
    api_airport_data_url = api_flightradar_base_url + "/airport.json"
    airport_data_url = flightradar_base_url + "/airports/traffic-stats/?airport={}"
    airports_data_url = flightradar_base_url + "/data/airports"

    # Airlines data URL.
    airlines_data_url = flightradar_base_url + "/data/airlines"

    # Zones data URL.
    zones_data_url = flightradar_base_url + "/js/zones.js.php"

    # Weather data URL.
    volcanic_eruption_data_url = flightradar_base_url + "/weather/volcanic"

    # Most tracked URL
    most_tracked_url = flightradar_base_url + "/flights/most-tracked"

    # Airport disruptions URL.
    airport_disruptions_url = flightradar_base_url + "/webapi/v1/airport-disruptions"

    # Bookmarks URL.
    bookmarks_url = flightradar_base_url + "/webapi/v1/bookmarks"

    # Country flag image URL.
    country_flag_url = flightradar_base_url + "/static/images/data/flags-small/{}.svg"

    # Airline logo image URL.
    airline_logo_url = cdn_flightradar_base_url + "/assets/airlines/logotypes/{}_{}.png"
    alternative_airline_logo_url = flightradar_base_url + "/static/images/data/operators/{}_logo0.png"

    static_zones = static_zones

    headers = {
        "accept-encoding": "gzip, br",
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "max-age=0",
        "origin": "https://www.flightradar24.com",
        "referer": "https://www.flightradar24.com/",
        "sec-ch-ua": '"Google Chrome";v="136", "Chromium";v="136", "Not-A.Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            " (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
        ),
    }

    json_headers = headers.copy()
    json_headers["accept"] = "application/json"

    image_headers = headers.copy()
    image_headers["accept"] = "image/gif, image/jpg, image/jpeg, image/png"

    html_headers = {
        "accept": (
            "text/html,application/xhtml+xml,application/xml;q=0.9,"
            "image/avif,image/webp,image/apng,*/*;q=0.8,"
            "application/signed-exchange;v=b3;q=0.7"
        ),
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "cache-control": "max-age=0",
        "referer": "https://www.flightradar24.com/",
        "sec-ch-ua": '"Google Chrome";v="136", "Chromium";v="136", "Not-A.Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            " (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
        ),
    }


class Countries(Enum):
    """
    Enum mapping country names in to their URL-friendly string representations.
    """
    AFGHANISTAN = "afghanistan"
    ALBANIA = "albania"
    ALGERIA = "algeria"
    AMERICAN_SAMOA = "american-samoa"
    ANGOLA = "angola"
    ANGUILLA = "anguilla"
    ANTARCTICA = "antarctica"
    ANTIGUA_AND_BARBUDA = "antigua-and-barbuda"
    ARGENTINA = "argentina"
    ARMENIA = "armenia"
    ARUBA = "aruba"
    AUSTRALIA = "australia"
    AUSTRIA = "austria"
    AZERBAIJAN = "azerbaijan"
    BAHAMAS = "bahamas"
    BAHRAIN = "bahrain"
    BANGLADESH = "bangladesh"
    BARBADOS = "barbados"
    BELARUS = "belarus"
    BELGIUM = "belgium"
    BELIZE = "belize"
    BENIN = "benin"
    BERMUDA = "bermuda"
    BHUTAN = "bhutan"
    BOLIVIA = "bolivia"
    BOSNIA_AND_HERZEGOVINA = "bosnia-and-herzegovina"
    BOTSWANA = "botswana"
    BRAZIL = "brazil"
    BRUNEI = "brunei"
    BULGARIA = "bulgaria"
    BURKINA_FASO = "burkina-faso"
    BURUNDI = "burundi"
    CAMBODIA = "cambodia"
    CAMEROON = "cameroon"
    CANADA = "canada"
    CAPE_VERDE = "cape-verde"
    CAYMAN_ISLANDS = "cayman-islands"
    CENTRAL_AFRICAN_REPUBLIC = "central-african-republic"
    CHAD = "chad"
    CHILE = "chile"
    CHINA = "china"
    COCOS_KEELING_ISLANDS = "cocos-keeling-islands"
    COLOMBIA = "colombia"
    COMOROS = "comoros"
    CONGO = "congo"
    COOK_ISLANDS = "cook-islands"
    COSTA_RICA = "costa-rica"
    CROATIA = "croatia"
    CUBA = "cuba"
    CURACAO = "curacao"
    CYPRUS = "cyprus"
    CZECHIA = "czechia"
    DEMOCRATIC_REPUBLIC_OF_THE_CONGO = "democratic-republic-of-the-congo"
    DENMARK = "denmark"
    DJIBOUTI = "djibouti"
    DOMINICA = "dominica"
    DOMINICAN_REPUBLIC = "dominican-republic"
    ECUADOR = "ecuador"
    EGYPT = "egypt"
    EL_SALVADOR = "el-salvador"
    EQUATORIAL_GUINEA = "equatorial-guinea"
    ERITREA = "eritrea"
    ESTONIA = "estonia"
    ESWATINI = "eswatini"
    ETHIOPIA = "ethiopia"
    FALKLAND_ISLANDS_MALVINAS = "falkland-islands-malvinas"
    FAROE_ISLANDS = "faroe-islands"
    FIJI = "fiji"
    FINLAND = "finland"
    FRANCE = "france"
    FRENCH_GUIANA = "french-guiana"
    FRENCH_POLYNESIA = "french-polynesia"
    GABON = "gabon"
    GAMBIA = "gambia"
    GEORGIA = "georgia"
    GERMANY = "germany"
    GHANA = "ghana"
    GIBRALTAR = "gibraltar"
    GREECE = "greece"
    GREENLAND = "greenland"
    GRENADA = "grenada"
    GUADELOUPE = "guadeloupe"
    GUAM = "guam"
    GUATEMALA = "guatemala"
    GUERNSEY = "guernsey"
    GUINEA = "guinea"
    GUINEA_BISSAU = "guinea-bissau"
    GUYANA = "guyana"
    HAITI = "haiti"
    HONDURAS = "honduras"
    HONG_KONG = "hong-kong"
    HUNGARY = "hungary"
    ICELAND = "iceland"
    INDIA = "india"
    INDONESIA = "indonesia"
    IRAN = "iran"
    IRAQ = "iraq"
    IRELAND = "ireland"
    ISLE_OF_MAN = "isle-of-man"
    ISRAEL = "israel"
    ITALY = "italy"
    IVORY_COAST = "ivory-coast"
    JAMAICA = "jamaica"
    JAPAN = "japan"
    JERSEY = "jersey"
    JORDAN = "jordan"
    KAZAKHSTAN = "kazakhstan"
    KENYA = "kenya"
    KIRIBATI = "kiribati"
    KOSOVO = "kosovo"
    KUWAIT = "kuwait"
    KYRGYZSTAN = "kyrgyzstan"
    LAOS = "laos"
    LATVIA = "latvia"
    LEBANON = "lebanon"
    LESOTHO = "lesotho"
    LIBERIA = "liberia"
    LIBYA = "libya"
    LITHUANIA = "lithuania"
    LUXEMBOURG = "luxembourg"
    MACAO = "macao"
    MADAGASCAR = "madagascar"
    MALAWI = "malawi"
    MALAYSIA = "malaysia"
    MALDIVES = "maldives"
    MALI = "mali"
    MALTA = "malta"
    MARSHALL_ISLANDS = "marshall-islands"
    MARTINIQUE = "martinique"
    MAURITANIA = "mauritania"
    MAURITIUS = "mauritius"
    MAYOTTE = "mayotte"
    MEXICO = "mexico"
    MICRONESIA = "micronesia"
    MOLDOVA = "moldova"
    MONACO = "monaco"
    MONGOLIA = "mongolia"
    MONTENEGRO = "montenegro"
    MONTSERRAT = "montserrat"
    MOROCCO = "morocco"
    MOZAMBIQUE = "mozambique"
    MYANMAR_BURMA = "myanmar-burma"
    NAMIBIA = "namibia"
    NAURU = "nauru"
    NEPAL = "nepal"
    NETHERLANDS = "netherlands"
    NEW_CALEDONIA = "new-caledonia"
    NEW_ZEALAND = "new-zealand"
    NICARAGUA = "nicaragua"
    NIGER = "niger"
    NIGERIA = "nigeria"
    NORTH_KOREA = "north-korea"
    NORTH_MACEDONIA = "north-macedonia"
    NORTHERN_MARIANA_ISLANDS = "northern-mariana-islands"
    NORWAY = "norway"
    OMAN = "oman"
    PAKISTAN = "pakistan"
    PALAU = "palau"
    PANAMA = "panama"
    PAPUA_NEW_GUINEA = "papua-new-guinea"
    PARAGUAY = "paraguay"
    PERU = "peru"
    PHILIPPINES = "philippines"
    POLAND = "poland"
    PORTUGAL = "portugal"
    PUERTO_RICO = "puerto-rico"
    QATAR = "qatar"
    REUNION = "reunion"
    ROMANIA = "romania"
    RUSSIA = "russia"
    RWANDA = "rwanda"
    SAINT_HELENA = "saint-helena"
    SAINT_KITTS_AND_NEVIS = "saint-kitts-and-nevis"
    SAINT_LUCIA = "saint-lucia"
    SAINT_PIERRE_AND_MIQUELON = "saint-pierre-and-miquelon"
    SAINT_VINCENT_AND_THE_GRENADINES = "saint-vincent-and-the-grenadines"
    SAMOA = "samoa"
    SAO_TOME_AND_PRINCIPE = "sao-tome-and-principe"
    SAUDI_ARABIA = "saudi-arabia"
    SENEGAL = "senegal"
    SERBIA = "serbia"
    SEYCHELLES = "seychelles"
    SIERRA_LEONE = "sierra-leone"
    SINGAPORE = "singapore"
    SLOVAKIA = "slovakia"
    SLOVENIA = "slovenia"
    SOLOMON_ISLANDS = "solomon-islands"
    SOMALIA = "somalia"
    SOUTH_AFRICA = "south-africa"
    SOUTH_KOREA = "south-korea"
    SOUTH_SUDAN = "south-sudan"
    SPAIN = "spain"
    SRI_LANKA = "sri-lanka"
    SUDAN = "sudan"
    SURINAME = "suriname"
    SWEDEN = "sweden"
    SWITZERLAND = "switzerland"
    SYRIA = "syria"
    TAIWAN = "taiwan"
    TAJIKISTAN = "tajikistan"
    TANZANIA = "tanzania"
    THAILAND = "thailand"
    TIMOR_LESTE_EAST_TIMOR = "timor-leste-east-timor"
    TOGO = "togo"
    TONGA = "tonga"
    TRINIDAD_AND_TOBAGO = "trinidad-and-tobago"
    TUNISIA = "tunisia"
    TURKEY = "turkey"
    TURKMENISTAN = "turkmenistan"
    TURKS_AND_CAICOS_ISLANDS = "turks-and-caicos-islands"
    TUVALU = "tuvalu"
    UGANDA = "uganda"
    UKRAINE = "ukraine"
    UNITED_ARAB_EMIRATES = "united-arab-emirates"
    UNITED_KINGDOM = "united-kingdom"
    UNITED_STATES = "united-states"
    UNITED_STATES_MINOR_OUTLYING_ISLANDS = "united-states-minor-outlying-islands"
    URUGUAY = "uruguay"
    UZBEKISTAN = "uzbekistan"
    VANUATU = "vanuatu"
    VENEZUELA = "venezuela"
    VIETNAM = "vietnam"
    VIRGIN_ISLANDS_BRITISH = "virgin-islands-british"
    VIRGIN_ISLANDS_US = "virgin-islands-us"
    WALLIS_AND_FUTUNA = "wallis-and-futuna"
    YEMEN = "yemen"
    ZAMBIA = "zambia"
    ZIMBABWE = "zimbabwe"
